title: 我在 GitHub 上的开源项目
date: '2019-06-20 15:20:53'
updated: '2019-06-20 15:20:53'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [gev](https://github.com/Allenxuxu/gev) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`11`](https://github.com/Allenxuxu/gev/watchers "关注数")&nbsp;&nbsp;[⭐️`516`](https://github.com/Allenxuxu/gev/stargazers "收藏数")&nbsp;&nbsp;[🖖`39`](https://github.com/Allenxuxu/gev/network/members "分叉数")</span>

🇨🇳gev 是基于Reactor模式实现的轻量级，快速，非阻塞式TCP网络库。/ gev is a lightweight, fast non-blocking TCP network library based on Reactor mode.



---

### 2. [microservices](https://github.com/Allenxuxu/microservices) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/Allenxuxu/microservices/watchers "关注数")&nbsp;&nbsp;[⭐️`103`](https://github.com/Allenxuxu/microservices/stargazers "收藏数")&nbsp;&nbsp;[🖖`27`](https://github.com/Allenxuxu/microservices/network/members "分叉数")&nbsp;&nbsp;[🏠`https://note.mogutou.xyz/category/go-micro`](https://note.mogutou.xyz/category/go-micro "项目主页")</span>

micro 微服务实例教程，包含JWT鉴权、熔断、监控、链路追踪、健康检查等



---

### 3. [mogutouERP](https://github.com/Allenxuxu/mogutouERP) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/Allenxuxu/mogutouERP/watchers "关注数")&nbsp;&nbsp;[⭐️`34`](https://github.com/Allenxuxu/mogutouERP/stargazers "收藏数")&nbsp;&nbsp;[🖖`10`](https://github.com/Allenxuxu/mogutouERP/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.mogutou.xyz`](https://www.mogutou.xyz "项目主页")</span>

轻进存销管理系统



---

### 4. [eviop](https://github.com/Allenxuxu/eviop) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/eviop/watchers "关注数")&nbsp;&nbsp;[⭐️`15`](https://github.com/Allenxuxu/eviop/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/Allenxuxu/eviop/network/members "分叉数")</span>

一个快速、轻便的事件循环网络框架



---

### 5. [mogutouERP-vue](https://github.com/Allenxuxu/mogutouERP-vue) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/mogutouERP-vue/watchers "关注数")&nbsp;&nbsp;[⭐️`11`](https://github.com/Allenxuxu/mogutouERP-vue/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/Allenxuxu/mogutouERP-vue/network/members "分叉数")</span>

轻进存销管理系统



---

### 6. [Xmqtt](https://github.com/Allenxuxu/Xmqtt) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/Allenxuxu/Xmqtt/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/Allenxuxu/Xmqtt/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/Allenxuxu/Xmqtt/network/members "分叉数")</span>





---

### 7. [AGV-Calling-device](https://github.com/Allenxuxu/AGV-Calling-device) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/AGV-Calling-device/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/Allenxuxu/AGV-Calling-device/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/AGV-Calling-device/network/members "分叉数")</span>





---

### 8. [data-structure](https://github.com/Allenxuxu/data-structure) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/data-structure/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/Allenxuxu/data-structure/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/data-structure/network/members "分叉数")</span>

C++ 类STL库



---

### 9. [solo-blog](https://github.com/Allenxuxu/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Allenxuxu/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Allenxuxu/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://note.mogutou.xyz`](https://note.mogutou.xyz "项目主页")</span>

徐旭 的个人博客 - 记录点点滴滴



---

### 10. [mogutou-index](https://github.com/Allenxuxu/mogutou-index) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/mogutou-index/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Allenxuxu/mogutou-index/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/mogutou-index/network/members "分叉数")</span>

蘑菇头官网主页

