title: Golang 项目使用 Github Actions
date: '2019-09-05 18:58:58'
updated: '2019-09-05 18:58:58'
tags: [GitHub]
permalink: /articles/2019/09/05/1567681138418.html
---
使用了一段时间的 Github Actions，GitHub 原生自带还是非常爽的。
CI/CD 该有的基本都有，还支持指定各种平台（Mac OS、Linux...）运行，对有跨平台需求的项目非常方便，配置一下即可以全平台测试。

分享一下自己 Go 跑 CI 的配置吧，没有包含账户或者仓库路径，想用的直接复制粘贴即可。

需要修改配置的，参考着官方文档修改就可以了-->[传送门](https://help.github.com/en/categories/automating-your-workflow-with-github-actions)

还没有用过 Github Actions 的小伙伴，可以登记下排队领试用--> [传送门](https://github.com/features/actions)

```
name: CI
on: [push,pull_request]
jobs:
  lint:
    name: Lint
    runs-on: ubuntu-18.04
    steps:
    - name: Set up Go 1.12
      uses: actions/setup-go@v1
      with:
        go-version: 1.12
      id: go
    - name: Code
      uses: actions/checkout@v1
    - name: Intsall Golangci-lint 
      run: curl -sfL https://raw.githubusercontent.com/golangci/golangci-lint/master/install.sh| sh -s -- -b . latest
    - name: Lint
      run: ./golangci-lint run ./...
      
  test:
    needs: Lint
    name: Unit Testing
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [macOS-10.14,ubuntu-18.04]
    steps:
    - name: Set up Go 1.12
      uses: actions/setup-go@v1
      with:
        go-version: 1.12
      id: go
    - name: Code
      uses: actions/checkout@v1
    - name: Go Get dependencies
      run: go get -v -t -d ./...
    - name: Go Test
      run: go test -v ./...
```


