title: Ubuntu 18.04 固定软件图标到侧边栏
date: '2019-08-20 08:18:27'
updated: '2019-08-20 09:21:05'
tags: [Ubuntu]
permalink: /articles/2019/08/20/1566260307439.html
---
![](https://img.hacpai.com/bing/20190522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

Ubuntu 18.04 中，从官网下载安装包自行安装的软件无法像 16.04 一样直接在侧边栏右击固定了。
这里以 GoLand 为例演示下怎么手动固定到侧边栏：

*  安装好 GoLand
*  `sudo vi /usr/share/applications/goland.desktop `
	```
 	[Desktop Entry]
	Version=1.0
	Terminal=false
	Type=Application
	Name=GoLand
	Exec=/home/xx/Documents/GoLand-2019.2/bin/goland.sh
	Icon=/home/xx/Documents/GoLand-2019.2/bin/goland.svg
	NoDisplay=false
	StartupWMClass=jetbrains-goland
	```
	
	这里 Exec 是软件启动命令，Icon 是软件的图标路径，注意使用绝对路径。

	添加其他软件时，StartupWMClass 中的内容可以先不填。不填不影响使用，但是启动时，侧边栏会出现两个图标。要消除这种现象，可以启动软件后执行：`xprop |grep WM_CLASS` 。鼠标光标会变成十字准心，点击已经打开的软件界面。将结果的第一个字符串填入 StartupWMClass。
* 保存文件，点击桌面左下角的 “显示应用程序”，找到 GoLand 然后右击添加到收藏夹。



##### 参考
https://blog.csdn.net/u014160286/article/details/81631863
https://askubuntu.com/questions/367396/what-does-the-startupwmclass-field-of-a-desktop-file-represent
