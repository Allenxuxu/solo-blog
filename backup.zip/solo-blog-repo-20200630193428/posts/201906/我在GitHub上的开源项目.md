title: 我在 GitHub 上的开源项目
date: '2019-06-20 15:20:53'
updated: '2019-06-20 15:20:53'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [gev](https://github.com/Allenxuxu/gev) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`31`](https://github.com/Allenxuxu/gev/watchers "关注数")&nbsp;&nbsp;[⭐️`867`](https://github.com/Allenxuxu/gev/stargazers "收藏数")&nbsp;&nbsp;[🖖`85`](https://github.com/Allenxuxu/gev/network/members "分叉数")</span>

🚀Gev is a lightweight, fast non-blocking TCP network library based on Reactor mode. Support custom protocols to quickly and easily build high-performance servers. 



---

### 2. [microservices](https://github.com/Allenxuxu/microservices) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`11`](https://github.com/Allenxuxu/microservices/watchers "关注数")&nbsp;&nbsp;[⭐️`282`](https://github.com/Allenxuxu/microservices/stargazers "收藏数")&nbsp;&nbsp;[🖖`68`](https://github.com/Allenxuxu/microservices/network/members "分叉数")&nbsp;&nbsp;[🏠`https://note.mogutou.xyz/category/go-micro`](https://note.mogutou.xyz/category/go-micro "项目主页")</span>

micro 微服务实例教程，包含JWT鉴权、熔断、监控、链路追踪、健康检查、跨域等



---

### 3. [mogutouERP](https://github.com/Allenxuxu/mogutouERP) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/Allenxuxu/mogutouERP/watchers "关注数")&nbsp;&nbsp;[⭐️`105`](https://github.com/Allenxuxu/mogutouERP/stargazers "收藏数")&nbsp;&nbsp;[🖖`33`](https://github.com/Allenxuxu/mogutouERP/network/members "分叉数")</span>

轻进存销管理系统  https://erp.mogutou.xyz



---

### 4. [mogutouERP-vue](https://github.com/Allenxuxu/mogutouERP-vue) <kbd title="主要编程语言">Vue</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/Allenxuxu/mogutouERP-vue/watchers "关注数")&nbsp;&nbsp;[⭐️`27`](https://github.com/Allenxuxu/mogutouERP-vue/stargazers "收藏数")&nbsp;&nbsp;[🖖`25`](https://github.com/Allenxuxu/mogutouERP-vue/network/members "分叉数")</span>

轻进存销管理系统 https://erp.mogutou.xyz



---

### 5. [ringbuffer](https://github.com/Allenxuxu/ringbuffer) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/Allenxuxu/ringbuffer/watchers "关注数")&nbsp;&nbsp;[⭐️`14`](https://github.com/Allenxuxu/ringbuffer/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/Allenxuxu/ringbuffer/network/members "分叉数")</span>

🚀🚀自动扩容的循环缓冲区实现



---

### 6. [eviop](https://github.com/Allenxuxu/eviop) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/eviop/watchers "关注数")&nbsp;&nbsp;[⭐️`14`](https://github.com/Allenxuxu/eviop/stargazers "收藏数")&nbsp;&nbsp;[🖖`6`](https://github.com/Allenxuxu/eviop/network/members "分叉数")</span>

eviop 不再继续开发，➡️ 更好更快，请移向 gev 项目➡️https://github.com/Allenxuxu/gev



---

### 7. [Xmqtt](https://github.com/Allenxuxu/Xmqtt) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`4`](https://github.com/Allenxuxu/Xmqtt/watchers "关注数")&nbsp;&nbsp;[⭐️`6`](https://github.com/Allenxuxu/Xmqtt/stargazers "收藏数")&nbsp;&nbsp;[🖖`5`](https://github.com/Allenxuxu/Xmqtt/network/members "分叉数")</span>





---

### 8. [data-structure](https://github.com/Allenxuxu/data-structure) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/data-structure/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/Allenxuxu/data-structure/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/data-structure/network/members "分叉数")</span>

C++ 类STL库



---

### 9. [solo-blog](https://github.com/Allenxuxu/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Allenxuxu/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Allenxuxu/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.mogutou.xyz`](https://www.mogutou.xyz "项目主页")</span>

✍️ 徐旭 的个人博客 - 礼法岂是为吾辈而设



---

### 10. [leetcode-in-go](https://github.com/Allenxuxu/leetcode-in-go) <kbd title="主要编程语言">Go</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Allenxuxu/leetcode-in-go/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Allenxuxu/leetcode-in-go/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Allenxuxu/leetcode-in-go/network/members "分叉数")</span>

leetcode go 语言题解

