title: 'XConf : Golang 构建的开源分布式配置中心 '
date: '2020-02-08 12:44:35'
updated: '2020-02-10 10:22:33'
tags: [go-micro, microservices, Go, Vue]
permalink: /articles/2020/02/08/1581137075011.html
---
[Github项目地址](https://github.com/micro-in-cn/XConf) | [线上demo](http://xconf.mogutou.xyz/admin/ui)

微服务架构愈演愈烈，但是社区一直缺少一个部署简便，高可用的配置中心。
`XConf` 是一个基于 go-micro 微服务框架构建的分布式配置中心，提供配置的管理与发布、实时推送。

![design.png](https://img.hacpai.com/file/2020/02/design-e988366e.png)

配置中心底层存储采用 MySQL 数据库，主要分为三个服务：
- config-srv : 负责底层配置的读写
- admin-api : 负责与管理页面交互，相关鉴权，账号体系也会与此模块交互
- agent-api : 负责与客户端交互，提供配置读取和推送。

配置中心本身就是一个“读多写少”的服务，所以在 agent-api 服务中增加缓存，从而有效增加并发性能。得益于 go-micro 框架，三个服务可以便捷的横向伸缩。例如，当获取配置的客户端较多时，可以增加 agent-api 实例。

配置获取采用 HTTP 方式实现，配置的实时推送采用 HTTP Long Polling（长轮询）方式实现。选择 HTTP 方式，更加便于各种语言接入配置中心。

Golang 语言读取配置和监听实时配置推送( ➡️ [源码地址](https://github.com/micro-in-cn/XConf/blob/master/client/example/main.go) )：

```go
package main

import (
	"github.com/micro-in-cn/XConf/client/source"
	"github.com/micro/go-micro/v2/config"
	"github.com/micro/go-micro/v2/util/log"
)

func main() {
	c, err := config.NewConfig(
		config.WithSource(
			source.NewSource("app", "dev", "test", source.WithURL("http://xconf.mogutou.xyz"))))
	if err != nil {
		panic(err)
	}
	log.Info("read: ", string(c.Get().Bytes()))

	// Watch 返回前 micro config 会调用 Read 读一次配置
	w, err := c.Watch()
	if err != nil {
		panic(err)
	}

	for {
		// 会比较 value，内容不变不会返回
		v, err := w.Next()
		if err != nil {
			panic(err)
		}

		log.Info("watch: ", string(v.Bytes()))
	}
}
```

XConf 当前还在持续开发中，欢迎大家的加入👏👏  

[Github项目地址](https://github.com/micro-in-cn/XConf) | [线上demo](http://xconf.mogutou.xyz/admin/ui)

---

> 管理页面截图：
![namespace.png](https://img.hacpai.com/file/2020/02/namespace-5f375f08.png)
![rollback.png](https://img.hacpai.com/file/2020/02/rollback-31968893.png)

